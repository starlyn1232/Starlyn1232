﻿namespace FileExtensionChanger
{
    partial class FileExtensionChanger
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FileExtensionChanger));
            this.btnStart = new System.Windows.Forms.Button();
            this.btnFolderFinder = new System.Windows.Forms.Button();
            this.tbFolderFinder = new System.Windows.Forms.TextBox();
            this.tbFinalExt = new System.Windows.Forms.TextBox();
            this.tbCurrentExt = new System.Windows.Forms.TextBox();
            this.lblFile = new System.Windows.Forms.Label();
            this.lblFinalExt = new System.Windows.Forms.Label();
            this.lblCurrentExt = new System.Windows.Forms.Label();
            this.lblCoder = new System.Windows.Forms.Label();
            this.lblCurrentExtPoint = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnClearFields = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.MistyRose;
            this.btnStart.Enabled = false;
            this.btnStart.Location = new System.Drawing.Point(454, 258);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(165, 64);
            this.btnStart.TabIndex = 6;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnFolderFinder
            // 
            this.btnFolderFinder.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnFolderFinder.Location = new System.Drawing.Point(541, 198);
            this.btnFolderFinder.Name = "btnFolderFinder";
            this.btnFolderFinder.Size = new System.Drawing.Size(80, 32);
            this.btnFolderFinder.TabIndex = 2;
            this.btnFolderFinder.Text = "Find Dir";
            this.btnFolderFinder.UseVisualStyleBackColor = false;
            this.btnFolderFinder.Click += new System.EventHandler(this.btnFolderFinder_Click);
            // 
            // tbFolderFinder
            // 
            this.tbFolderFinder.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbFolderFinder.Location = new System.Drawing.Point(24, 198);
            this.tbFolderFinder.Name = "tbFolderFinder";
            this.tbFolderFinder.ReadOnly = true;
            this.tbFolderFinder.Size = new System.Drawing.Size(495, 32);
            this.tbFolderFinder.TabIndex = 1;
            // 
            // tbFinalExt
            // 
            this.tbFinalExt.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbFinalExt.Location = new System.Drawing.Point(229, 272);
            this.tbFinalExt.Name = "tbFinalExt";
            this.tbFinalExt.Size = new System.Drawing.Size(129, 32);
            this.tbFinalExt.TabIndex = 4;
            this.tbFinalExt.TextChanged += new System.EventHandler(this.tbFinalExt_TextChanged);
            // 
            // tbCurrentExt
            // 
            this.tbCurrentExt.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbCurrentExt.Location = new System.Drawing.Point(27, 272);
            this.tbCurrentExt.Name = "tbCurrentExt";
            this.tbCurrentExt.Size = new System.Drawing.Size(149, 32);
            this.tbCurrentExt.TabIndex = 3;
            this.tbCurrentExt.TextChanged += new System.EventHandler(this.tbCurrentExt_TextChanged);
            // 
            // lblFile
            // 
            this.lblFile.AutoSize = true;
            this.lblFile.Location = new System.Drawing.Point(25, 169);
            this.lblFile.Name = "lblFile";
            this.lblFile.Size = new System.Drawing.Size(90, 15);
            this.lblFile.TabIndex = 5;
            this.lblFile.Text = "Selected Folder:";
            // 
            // lblFinalExt
            // 
            this.lblFinalExt.AutoSize = true;
            this.lblFinalExt.Location = new System.Drawing.Point(225, 247);
            this.lblFinalExt.Name = "lblFinalExt";
            this.lblFinalExt.Size = new System.Drawing.Size(106, 15);
            this.lblFinalExt.TabIndex = 6;
            this.lblFinalExt.Text = "Convert Extension:";
            // 
            // lblCurrentExt
            // 
            this.lblCurrentExt.AutoSize = true;
            this.lblCurrentExt.Location = new System.Drawing.Point(24, 247);
            this.lblCurrentExt.Name = "lblCurrentExt";
            this.lblCurrentExt.Size = new System.Drawing.Size(104, 15);
            this.lblCurrentExt.TabIndex = 7;
            this.lblCurrentExt.Text = "Current Extension:";
            // 
            // lblCoder
            // 
            this.lblCoder.AutoSize = true;
            this.lblCoder.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCoder.Location = new System.Drawing.Point(25, 380);
            this.lblCoder.Name = "lblCoder";
            this.lblCoder.Size = new System.Drawing.Size(128, 16);
            this.lblCoder.TabIndex = 8;
            this.lblCoder.Text = "Code By Starlyn1232";
            // 
            // lblCurrentExtPoint
            // 
            this.lblCurrentExtPoint.AutoSize = true;
            this.lblCurrentExtPoint.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCurrentExtPoint.Location = new System.Drawing.Point(9, 274);
            this.lblCurrentExtPoint.Name = "lblCurrentExtPoint";
            this.lblCurrentExtPoint.Size = new System.Drawing.Size(19, 30);
            this.lblCurrentExtPoint.TabIndex = 9;
            this.lblCurrentExtPoint.Text = ".";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(214, 274);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 30);
            this.label1.TabIndex = 10;
            this.label1.Text = ".";
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(28, 337);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(591, 23);
            this.progressBar.TabIndex = 11;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(41, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 127);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 17F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.lblTitle.Location = new System.Drawing.Point(195, 71);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(424, 31);
            this.lblTitle.TabIndex = 13;
            this.lblTitle.Text = "File Extension Changer By Starlyn1232";
            // 
            // btnClearFields
            // 
            this.btnClearFields.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnClearFields.Enabled = false;
            this.btnClearFields.Location = new System.Drawing.Point(366, 274);
            this.btnClearFields.Name = "btnClearFields";
            this.btnClearFields.Size = new System.Drawing.Size(80, 32);
            this.btnClearFields.TabIndex = 5;
            this.btnClearFields.Text = "Clear";
            this.btnClearFields.UseVisualStyleBackColor = false;
            this.btnClearFields.Click += new System.EventHandler(this.btnClearFields_Click);
            // 
            // FileExtensionChanger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 406);
            this.Controls.Add(this.btnClearFields);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.tbCurrentExt);
            this.Controls.Add(this.tbFinalExt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblCurrentExtPoint);
            this.Controls.Add(this.lblCoder);
            this.Controls.Add(this.lblCurrentExt);
            this.Controls.Add(this.lblFinalExt);
            this.Controls.Add(this.lblFile);
            this.Controls.Add(this.tbFolderFinder);
            this.Controls.Add(this.btnFolderFinder);
            this.Controls.Add(this.btnStart);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FileExtensionChanger";
            this.Text = "FileExtensionChanger by Starlyn1232 v1.0";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FileExtensionChanger_FormClosing);
            this.Load += new System.EventHandler(this.FileExtensionChanger_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnStart;
        private Button btnFolderFinder;
        private TextBox tbFolderFinder;
        private TextBox tbFinalExt;
        private TextBox tbCurrentExt;
        private Label lblFile;
        private Label lblFinalExt;
        private Label lblCurrentExt;
        private Label lblCoder;
        private Label lblCurrentExtPoint;
        private Label label1;
        private ProgressBar progressBar;
        private PictureBox pictureBox1;
        private Label lblTitle;
        private Button btnClearFields;
    }
}